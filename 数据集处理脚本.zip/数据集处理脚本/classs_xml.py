#7类
import xml.etree.ElementTree as ET
import os

# xmlfilepath = 'new_xml/'
# xmlfilepath = 'data/test'
xmlfilepath = '1/'

total_xml = os.listdir(xmlfilepath)
lists = []  
haozao = 0
aoxian = 0
heiban = 0
liekou = 0
niaozhuo = 0
gantiao = 0
lanzao = 0
shuzao = 0
popi = 0
for i in total_xml:
    i = '1/' + i
    tree = ET.parse(i)
    root = tree.getroot()
    for names in root.findall("object"):
        name = names.find('name').text
        if name == "4" or name == "HaoZao":
            haozao += 1
        elif name == "1" or name == "HeiBan":
            heiban += 1
        elif name == "5" or name == "NiaoZhuo":
            niaozhuo += 1
        elif name == "0" or name == "AoXian":
            aoxian += 1
        elif name == "2" or name == "GanTiao":
            gantiao += 1
        elif name == "6" or name == "LanZao":
            lanzao += 1
        elif name == "7" or name == "ShuZao":
            shuzao += 1
        elif name == "8" or name == "PoPi":
            popi += 1
        elif name == "3" or name == "LieKou":
            liekou += 1
zs = haozao + gantiao + heiban + liekou + aoxian + niaozhuo + lanzao + shuzao
print("统计数据集各类数量如下：好枣-%s-,干条-%s-,黑斑-%s-,裂口-%s-,凹陷-%s-,鸟琢-%s-,烂枣-%s-,竖枣-%s-,破皮-%s-,总数-%s-" % (haozao, gantiao, heiban, liekou, aoxian, niaozhuo, lanzao, shuzao, popi,zs))

# 统计数据集各类数量如下：好枣-1184-,干条-17255-,黑斑-48-,裂口-2-,凹陷-167-,鸟琢-21-,烂枣-4-,竖枣-3-,破皮-0-,总数-18684-

# 统计数据集各类数量如下：好枣-75-,干条-18279-,黑斑-59-,裂口-12-,凹陷-212-,鸟琢-19-,烂枣-4-,竖枣-7-,破皮-14-,总数-18667-

# 统计数据集各类数量如下：好枣-11921-,干条-53-,黑斑-103-,裂口-155-,凹陷-770-,鸟琢-11-,烂枣-1-,竖枣-12-,破皮-227-,总数-13026-

# 6类
# import xml.etree.ElementTree as ET
# import os
#
# xmlfilepath = 'new_xml/'
# total_xml = os.listdir(xmlfilepath)
# lists = []
# haozao = 0
# aoxian = 0
# heiban = 0
# liekou = 0
# niaozhuo = 0
# gantiao = 0
# for i in total_xml:
#     i = 'new_xml/' + i
#     tree = ET.parse(i)
#     root = tree.getroot()
#     for names in root.findall("object"):
#         name = names.find('name').text
#         if name == "HaoZao":
#             haozao += 1
#         elif name == "HeiBan":
#             heiban += 1
#         elif name == "NiaoZhuo":
#             niaozhuo += 1
#         elif name == "AoXian":
#             aoxian += 1
#         elif name == "GanTiao":
#             gantiao += 1
#         else:
#             liekou += 1
# zs = haozao+ gantiao+ heiban+ liekou+ aoxian+ niaozhuo
# print("统计数据集各类数量如下：好枣-%s-,干条-%s-,黑斑-%s-,裂口-%s-,凹陷-%s-,鸟琢-%s-,总数-%s-" % (haozao, gantiao, heiban, liekou, aoxian, niaozhuo, zs))