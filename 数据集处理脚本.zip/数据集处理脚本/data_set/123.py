import os
a = os.listdir("./1")
alist = []
for i in range(104, 2637, 15):
    s = "jujube_"+str(i)+".bmp"
    print(s)
    alist.append(s)

for i in a:
    if i in alist:
        os.remove("1/"+i)
        print(i)