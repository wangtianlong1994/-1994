# 修改图片名称
import os
lists = []
paths = "images/huaizao/"
image_list = os.listdir("images/huaizao")
a = 1058
for i in range(len(image_list)):
    os.rename(paths+image_list[i],(paths+"Jujube_"+str(a)+".bmp"))
    a += 1
    # os.rename(image_path,iamge_name)