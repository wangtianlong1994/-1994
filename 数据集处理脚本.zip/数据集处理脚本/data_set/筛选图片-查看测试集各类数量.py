# 筛选不存在的图片
#import os

#xml_list = os.listdir("Annotations")
#image_list = os.listdir("images")
#lists = []
#for image in image_list:
#    i = image.split('.')
#    i = i[0]
#    lists.append(i)
#for xml in xml_list:
#    x = xml.split('.')
#    x = x[0]
#    if x not in lists:
#       print(x)
#       f = open('no_image.txt', 'a')
#        f.write(x+"\n")

# import os, shutil
#
# f = open("no_image.txt", "r")
# file_list = f.read()
# f.close()
#
# fl = file_list.split("\n")
# os.mkdir("new_images")
# for i in fl:
#     print(i+".bmp")
#     shutil.move("images/"+i+".bmp", "new_images/"+i+".bmp")


#
# # 挑出测试集xml文件，并统计测试集的枣类数量，看是否对训练集产生影响
# import os
# import shutil
#
# filedir = os.listdir("Annotations")
#
# f = open("ImageSets/trainval.txt", "r")
# list = f.read()
# f.close()
# s = list.split("\n")
# for i in s:
#     for s in range(len(filedir)):
#         if i+".xml" == filedir[s]:
#             shutil.copyfile("Annotations/"+filedir[s], "test/"+filedir[s])
