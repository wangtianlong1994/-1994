# 修改xml文件名称
import os
lists = []
paths = "Annotations/"
xml_list = os.listdir("Annotations")

a = 0
for xml_name in xml_list:
    xml_name = "new_" + xml_name
    lists.append(xml_name)

for xmls in lists:
    image_path = paths + xml_list[a]
    iamge_name = paths + xmls
    # os.rename(image_path, iamge_name)
    a += 1
    os.rename(image_path,iamge_name)
