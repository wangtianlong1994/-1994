# 筛选不存在的图片
import os

xml_list = os.listdir("Annotations")
image_list = os.listdir("images")
lists = []
for image in image_list:
    i = image.split('.')
    i = i[0]
    lists.append(i)
for xml in xml_list:
    x = xml.split('.')
    x = x[0]
    if x not in lists:
        print(x)