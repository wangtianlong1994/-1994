import xml.etree.ElementTree as ET
import os

xmlfilepath = 'Annotations'
total_xml = os.listdir(xmlfilepath)
lists = []
haozao = 0
aoxian = 0
heiban = 0
liekou = 0
niaozhuo = 0
gantiao = 0
lanzao = 0
shuzao = 0
popi = 0
for i in total_xml:
    i = 'Annotations/' + i
    tree = ET.parse(i)
    root = tree.getroot()
    for names in root.findall("object"):
        name = names.find('name').text
        if name == "HaoZao":
            haozao += 1
        elif name == "HeiBan":
            heiban += 1
        elif name == "NiaoZhuo":
            niaozhuo += 1
        elif name == "AoXian":
            aoxian += 1
        elif name == "GanTiao":
            gantiao += 1
        elif name == "LanZao":
            lanzao += 1
        elif name == "ShuZao":
            shuzao += 1
        elif name == "PoPi":
            popi += 1
        else:
            liekou += 1
print("统计数据集各类数量如下：好枣-%s-,干条-%s-,黑斑-%s-,裂口-%s-,凹陷-%s-,鸟琢-%s-,烂枣-%s-,竖枣-%s-,破皮-%s-" % (haozao, gantiao, heiban, liekou, aoxian, niaozhuo, lanzao, shuzao, popi))