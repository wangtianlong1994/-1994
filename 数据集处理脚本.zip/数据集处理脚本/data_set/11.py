a = list()
path = r'1.txt'
with open(path, 'r', encoding='utf-8') as f:
    for line in f:
        value = line[:-1] #去掉换行符
        a.append(value)

b = list()
path1 = r'3.txt'
with open(path1, 'r', encoding='utf-8') as f1:
    for line1 in f1:
        value1 = line1[:-1] #去掉换行符
        b.append(value1)


for i in a:
    if i in b:
        print(i)


