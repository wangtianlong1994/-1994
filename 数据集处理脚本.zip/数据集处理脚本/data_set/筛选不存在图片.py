# # 筛选不存在的图片
# import os
#
# xml_list = os.listdir("images")
# image_list = os.listdir("Annotations")
# lists = []
# for image in image_list:
#     i = image.split('.')
#     i = i[0]
#     lists.append(i)
# for xml in xml_list:
#     x = xml.split('.')
#     x = x[0]
#     if x not in lists:
#         print(x)


# 缩放图片
from PIL import Image
import os
img_path = os.listdir("./111")

for i in img_path:
    img = Image.open(os.path.join("./111", i))

    out = img.resize((640, 640))

    out.save("2/%s.jpg" % i.split(".")[0])
