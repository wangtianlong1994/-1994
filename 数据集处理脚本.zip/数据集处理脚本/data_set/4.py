# import os
# import xml.etree.ElementTree as ET
#
# paths = "Annotations/"
# xml_list = os.listdir(paths)
# for xmls in xml_list:
#     tree = ET.parse(paths + xmls)
#     root = tree.getroot()
#     root.find("filename").text = xmls
#     tree.write(paths + xmls)

# #修改xml节点名称
# import os
# from xml.dom.minidom import parse
#
# def readXML():
#     for i in os.listdir("5"):
#         domTree = parse("5/"+i)
#         s = "5/"+i
#         # 文档根元素
#         rootNode = domTree.documentElement
#         # print(rootNode.nodeName)
#         customers = rootNode.getElementsByTagName("name")
#
#         domTree1 = parse("4/" + i)
#         # 文档根元素
#         rootNode1 = domTree1.documentElement
#         # print(rootNode.nodeName)
#         customers1 = rootNode1.getElementsByTagName("name")
#         for i in range(len(customers1)):
#             if "PoPi" in str(customers1[i].firstChild.data):
#                 print("改变前："+customers[i].firstChild.data)
#                 customers[i].firstChild.data = customers1[i].firstChild.data
#                 print("改变后："+customers[i].firstChild.data)
#
#         with open(s, 'w') as fh:
#             rootNode.writexml(fh)
# if __name__ == '__main__':
#     readXML()
#


#修改xml节点名称
import os
from xml.dom.minidom import parse

def readXML():
    for i in os.listdir("凹陷"):
        domTree = parse("凹陷/"+i)
        s = "凹陷/"+i
        # 文档根元素
        rootNode = domTree.documentElement
        # print(rootNode.nodeName)
        customers = rootNode.getElementsByTagName("name")

        for i in range(len(customers)):
            if "PoPi" in str(customers[i].firstChild.data):
                print(s)
        #         print("改变前："+customers[i].firstChild.data)
        #         customers[i].firstChild.data = "HaoZao"
        #         print("改变后："+customers[i].firstChild.data)
        #
        # with open(s, 'w') as fh:
        #     rootNode.writexml(fh)
if __name__ == '__main__':
    readXML()

