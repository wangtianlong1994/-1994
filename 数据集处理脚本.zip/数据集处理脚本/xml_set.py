# #对比xml文件是否有漏框
# import os
# from xml.dom.minidom import parse
#
# def readXML():
#     for i in os.listdir("Annotations"):
#         domTree = parse("Annotations/"+i)
#         # 文档根元素
#         rootNode = domTree.documentElement
#         # print(rootNode.nodeName)
#         customers = rootNode.getElementsByTagName("name")
#         a = 0
#         for customer in customers:
#             a += 1
#         if a == 20 or a == 16:
#             pass
#         else:
#             print(i)
#
# if __name__ == '__main__':
#     readXML()

#修改两个同样的xml文件统一某类
import os
from xml.dom.minidom import parse

def readXML():
    a = 0
    for i in os.listdir("Annotations_id_5"):
        domTree = parse("Annotations_id_5/"+i)
        # 文档根元素
        rootNode = domTree.documentElement
        # print(rootNode.nodeName)
        customers = rootNode.getElementsByTagName("name")
        for d in range(len(customers)):
            if str(customers[d].firstChild.data).split("_")[0] == "FengBan":
                b = str(customers[d].firstChild.data).split("_")[1]
                c = "Annotations_id_gan/" + i
                domTree1 = parse("Annotations_id_gan/" + i)
                rootNode1 = domTree1.documentElement
                customers1 = rootNode1.getElementsByTagName("name")
                for ii in range(len(customers1)):
                    if str(ii) == b:
                        a += 1
                        customers1[ii].firstChild.data = "FengBan" + "_" + b
                        print(customers1[ii].firstChild.data)
                with open(c, 'w') as fh:
                    rootNode1.writexml(fh)

if __name__ == '__main__':
    readXML()