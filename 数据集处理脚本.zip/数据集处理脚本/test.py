import time

a = []
while True:
    time.sleep(1)
    a.append("1")
    print()



