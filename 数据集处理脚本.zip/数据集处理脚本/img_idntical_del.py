from PIL import Image
from PIL import ImageChops
import os

img_path = os.listdir("images")
join_path = "images/"
image_one = Image.open(join_path+"Jujube_03684.bmp")
image_two = Image.open(join_path+"Jujube_03684.bmp")

diff = ImageChops.difference(image_one, image_two)

if diff.getbbox() is None:
    # 图片间没有任何不同则直接退出
    print("%s和%s相同" % (image_one ,image_two))
else:
    print("不同")



# def main():
#     num = 0
#     for i in img_path:
#         if compare_images(os.path.join(join_path, i), os.path.join(join_path, img_path[num])):
#             print(img_path[num])
#         num += 1
#
# main()
