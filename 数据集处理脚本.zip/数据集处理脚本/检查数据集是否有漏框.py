#检查数据集是否有漏框，并提出异常文件
import os
from xml.dom.minidom import parse
import shutil
def readXML():

    new_xml = "new_xml/"
    old_xml = "old_xml/"

    for i in os.listdir("OLD_XML"):
        domTree = parse("OLD_XML/"+i)
        s = "NEW_XML/"+i
        ss = "OLD_XML/"+i
        # 文档根元素
        rootNode = domTree.documentElement
        # print(rootNode.nodeName)
        customers = rootNode.getElementsByTagName("name")

        domTree1 = parse("NEW_XML/" + i)
        rootNode1 = domTree1.documentElement
        customers1 = rootNode1.getElementsByTagName("name")
        print(len(customers),len(customers1))
        if len(customers) == len(customers1):
            print(i + "：比对一致")
            continue
        else:
            shutil.copy(s, new_xml+i)
            shutil.copy(ss, old_xml+i)


if __name__ == '__main__':
    readXML()
#
import os
import shutil

for i in os.listdir("new_xml"):
    s = i.split(".")[0]
    shutil.copy("images/"+s+".bmp", "new_img/" + s + ".bmp")