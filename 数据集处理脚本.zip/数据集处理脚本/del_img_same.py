# 检查图片是否有相同

import os
import shutil
from time import *
import cv2 as cv
from skimage.measure import compare_ssim

EXT = ['.bmp', '.jpg']


def delete(imgs_n):
    for image in imgs_n:
        shutil.move(image, os.path.join("same_img_file",image.split("/")[-1]))
        # os.remove(image)


def find_sim_images(dir_path):
    imgs_n = []
    img_files = [os.path.join(rootdir, file) for rootdir, _, files in os.walk(dir_path) for file in files if
                 (os.path.splitext(file)[-1] in EXT)]
    for currIndex, filename in enumerate(img_files):
        num = 0
        if filename in imgs_n:
            continue
        if currIndex >= len(img_files) - 1:
            break
        for filename2 in img_files[currIndex + 1:]:

            begin_time = time()
            if filename2 in imgs_n:
                continue
            img = cv.imread(filename)
            img1 = cv.imread(filename2)
            try:
                ssim = compare_ssim(img, img1, multichannel=True)
                if ssim > 0.9:
                    imgs_n.append(filename2)
                    print(filename, filename2, ssim)
                    fn = open("./img_vs_img",'a+')
                    fn.write(filename+"--vs--"+filename2+"--=--"+str(ssim)+"\r\n")
                    fn.close()
                end_time = time()
                run_time = end_time - begin_time
                num += 1
                print('当前比较图片为：%s==>%s,检查一次时间为：%s,第%s次\n ssin值为：%s' % (filename,filename2,run_time,num,ssim))
            except ValueError:
                pass
    print(imgs_n)
    return imgs_n


if __name__ == '__main__':
    path = './2'
    delete(find_sim_images(path))

# # 缩放图片
# from PIL import Image
# import os
# img_path = os.listdir("./images")
#
# for i in img_path:
#     img = Image.open(os.path.join("./images", i))
#
#     out = img.resize((256, 200))
#
#     out.save("2/%s.jpg" % i.split(".")[0])

# import os
#
# file_path = os.listdir("same_img_file")
#
# for i in file_path:
#     s = i.split(".")[0]
#     s += ".xml"
#     print(s)
#     os.remove(os.path.join("Annotations", s))